#!/bin/bash

# HTB MCP Server Runner Script
# This script sets up and runs the HackTheBox MCP Server

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}=== HackTheBox MCP Server ===${NC}"
echo ""

# Load environment variables from .env file if it exists
if [ -f ".env" ]; then
    echo -e "${GREEN}Loading configuration from .env file${NC}"
    export $(cat .env | grep -v '^#' | xargs)
fi

# Check if HTB_TOKEN is set
if [ -z "$HTB_TOKEN" ]; then
    echo -e "${RED}Error: HTB_TOKEN is not set!${NC}"
    echo ""
    echo "Please ensure .env file exists with your HTB token"
    exit 1
else
    echo -e "${GREEN}HTB Token loaded successfully${NC}"
fi

# Optional configuration
export SERVER_PORT="${SERVER_PORT:-3000}"
export LOG_LEVEL="${LOG_LEVEL:-INFO}"
export RATE_LIMIT_PER_MINUTE="${RATE_LIMIT_PER_MINUTE:-100}"
export CACHE_TTL_SECONDS="${CACHE_TTL_SECONDS:-300}"
export REQUEST_TIMEOUT_SECONDS="${REQUEST_TIMEOUT_SECONDS:-30}"

echo "Configuration:"
echo "  Server Port: $SERVER_PORT"
echo "  Log Level: $LOG_LEVEL"
echo "  Rate Limit: $RATE_LIMIT_PER_MINUTE requests/minute"
echo "  Cache TTL: $CACHE_TTL_SECONDS seconds"
echo "  Request Timeout: $REQUEST_TIMEOUT_SECONDS seconds"
echo ""

# Check if binary exists
if [ ! -f "./htb-mcp-server" ]; then
    echo -e "${YELLOW}Binary not found. Building...${NC}"
    go build -o htb-mcp-server main.go
    if [ $? -ne 0 ]; then
        echo -e "${RED}Build failed!${NC}"
        exit 1
    fi
    echo -e "${GREEN}Build successful!${NC}"
fi

echo -e "${GREEN}Starting HTB MCP Server...${NC}"
echo "----------------------------------------"

# Run the server
./htb-mcp-server