#!/usr/bin/env python3
"""
HTB MCP Client - Interface to interact with the HackTheBox MCP Server
"""

import json
import sys
import subprocess
import time
from typing import Dict, Any, Optional

class HTBClient:
    def __init__(self):
        self.request_id = 0
        
    def _send_request(self, method: str, params: Optional[Dict] = None) -> Dict:
        """Send a JSON-RPC request to the MCP server"""
        self.request_id += 1
        request = {
            "jsonrpc": "2.0",
            "id": self.request_id,
            "method": method,
            "params": params or {}
        }
        
        # Send request via stdio to the MCP server
        process = subprocess.Popen(
            ["/workspace/htb-mcp-server/htb-mcp-server"],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env={"HTB_TOKEN": open("/workspace/htb-mcp-server/.env").read().split("\n")[1].split("=")[1]}
        )
        
        request_str = json.dumps(request) + "\n"
        stdout, stderr = process.communicate(input=request_str.encode())
        
        if stderr:
            print(f"Error: {stderr.decode()}")
            
        try:
            response = json.loads(stdout.decode().strip())
            return response
        except json.JSONDecodeError:
            return {"error": f"Failed to parse response: {stdout.decode()}"}
    
    def initialize(self):
        """Initialize the MCP session"""
        return self._send_request("initialize", {
            "protocolVersion": "0.1.0",
            "capabilities": {}
        })
    
    def list_tools(self):
        """List available tools"""
        return self._send_request("tools/list")
    
    def call_tool(self, tool_name: str, arguments: Dict[str, Any]):
        """Call a specific tool"""
        return self._send_request("tools/call", {
            "name": tool_name,
            "arguments": arguments
        })
    
    # HTB-specific convenience methods
    def list_challenges(self, category: str = None, difficulty: str = None, limit: int = 10):
        """List HTB challenges"""
        args = {"limit": limit}
        if category:
            args["category"] = category
        if difficulty:
            args["difficulty"] = difficulty
        return self.call_tool("list_challenges", args)
    
    def list_machines(self, status: str = "active", limit: int = 10):
        """List HTB machines"""
        return self.call_tool("list_machines", {
            "status": status,
            "limit": limit
        })
    
    def get_user_profile(self):
        """Get current user profile"""
        return self.call_tool("get_user_profile", {})
    
    def search_content(self, query: str, content_type: str = "all"):
        """Search HTB content"""
        return self.call_tool("search_content", {
            "query": query,
            "type": content_type
        })
    
    def start_machine(self, machine_id: int):
        """Start a machine"""
        return self.call_tool("start_machine", {
            "machine_id": machine_id
        })
    
    def submit_flag(self, flag: str, machine_id: int = None, challenge_id: int = None, flag_type: str = "user"):
        """Submit a flag"""
        args = {"flag": flag}
        if machine_id:
            if flag_type == "user":
                return self.call_tool("submit_user_flag", {
                    "machine_id": machine_id,
                    "flag": flag
                })
            else:
                return self.call_tool("submit_root_flag", {
                    "machine_id": machine_id,
                    "flag": flag
                })
        elif challenge_id:
            return self.call_tool("submit_challenge_flag", {
                "challenge_id": challenge_id,
                "flag": flag
            })
        else:
            return {"error": "Must specify either machine_id or challenge_id"}

def main():
    """Main function for testing the client"""
    client = HTBClient()
    
    print("=== HTB MCP Client Test ===\n")
    
    # Test initialization
    print("1. Initializing MCP session...")
    result = client.initialize()
    print(f"   Result: {json.dumps(result, indent=2)}\n")
    
    # List available tools
    print("2. Listing available tools...")
    result = client.list_tools()
    print(f"   Result: {json.dumps(result, indent=2)}\n")
    
    # Get user profile
    print("3. Getting user profile...")
    result = client.get_user_profile()
    print(f"   Result: {json.dumps(result, indent=2)}\n")
    
    # List active machines
    print("4. Listing active machines...")
    result = client.list_machines(status="active", limit=5)
    print(f"   Result: {json.dumps(result, indent=2)}\n")
    
    # List challenges
    print("5. Listing Web challenges...")
    result = client.list_challenges(category="Web", limit=5)
    print(f"   Result: {json.dumps(result, indent=2)}\n")

if __name__ == "__main__":
    main()