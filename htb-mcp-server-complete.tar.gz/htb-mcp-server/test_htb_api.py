#!/usr/bin/env python3
"""
Test direct HTB API connection
"""

import requests
import json

# Read token from .env file
with open('/workspace/htb-mcp-server/.env', 'r') as f:
    for line in f:
        if line.startswith('HTB_TOKEN='):
            token = line.strip().split('=')[1]
            break

# HTB API base URL
base_url = "https://labs.hackthebox.com/api/v4"

# Headers with authentication
headers = {
    "Authorization": f"Bearer {token}",
    "Accept": "application/json",
    "Content-Type": "application/json"
}

print("=== Testing HTB API Connection ===\n")

# Test 1: Get user profile
print("1. Getting user profile...")
try:
    response = requests.get(f"{base_url}/user/profile", headers=headers)
    if response.status_code == 200:
        user_data = response.json()
        print(f"   ✓ Connected as: {user_data.get('profile', {}).get('name', 'Unknown')}")
        print(f"   User ID: {user_data.get('profile', {}).get('id', 'Unknown')}")
        print(f"   Rank: {user_data.get('profile', {}).get('rank', 'Unknown')}")
    else:
        print(f"   ✗ Error: {response.status_code} - {response.text}")
except Exception as e:
    print(f"   ✗ Connection error: {e}")

print()

# Test 2: List active machines
print("2. Getting active machines...")
try:
    response = requests.get(f"{base_url}/machine/list", headers=headers)
    if response.status_code == 200:
        machines = response.json()
        print(f"   ✓ Found {len(machines.get('data', []))} machines")
        for machine in machines.get('data', [])[:3]:  # Show first 3
            print(f"      - {machine.get('name')} ({machine.get('difficultyText')})")
    else:
        print(f"   ✗ Error: {response.status_code} - {response.text}")
except Exception as e:
    print(f"   ✗ Connection error: {e}")

print()

# Test 3: List challenges
print("3. Getting challenges...")
try:
    response = requests.get(f"{base_url}/challenge/list", headers=headers)
    if response.status_code == 200:
        challenges = response.json()
        print(f"   ✓ Found {len(challenges.get('data', []))} challenges")
        # Group by category
        categories = {}
        for challenge in challenges.get('data', []):
            cat = challenge.get('category_name', 'Unknown')
            categories[cat] = categories.get(cat, 0) + 1
        for cat, count in list(categories.items())[:5]:
            print(f"      - {cat}: {count} challenges")
    else:
        print(f"   ✗ Error: {response.status_code} - {response.text}")
except Exception as e:
    print(f"   ✗ Connection error: {e}")

print("\n=== API Connection Test Complete ===")