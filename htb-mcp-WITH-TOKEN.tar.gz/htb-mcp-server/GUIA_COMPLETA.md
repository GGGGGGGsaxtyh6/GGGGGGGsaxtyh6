# 🚀 GUÍA COMPLETA HTB MCP SERVER

## 📦 INSTALACIÓN DESDE CERO

### 1. Requisitos Previos
```bash
# Instalar Go (si no lo tienes)
wget https://go.dev/dl/go1.21.0.linux-amd64.tar.gz
sudo tar -C /usr/local -xzf go1.21.0.linux-amd64.tar.gz
export PATH=$PATH:/usr/local/go/bin

# Verificar instalación
go version
```

### 2. Compilar el Servidor
```bash
# Entrar a la carpeta
cd htb-mcp-server

# Compilar
go build -o htb-mcp-server main.go
```

### 3. Configurar Token HTB
```bash
# Crear archivo .env con tu token
cat > .env << EOF
HTB_TOKEN=tu_token_aqui_entre_comillas
SERVER_PORT=3000
LOG_LEVEL=INFO
RATE_LIMIT_PER_MINUTE=100
CACHE_TTL_SECONDS=300
REQUEST_TIMEOUT_SECONDS=30
EOF
```

**Para obtener tu token:**
1. Ve a https://app.hackthebox.com/profile/settings
2. Sección "App Tokens"
3. Click en "Create App Token"
4. Copia el token (formato: eyJ0eXAi...)

### 4. Ejecutar el Servidor
```bash
# Dar permisos de ejecución
chmod +x htb-mcp-server

# Ejecutar
./htb-mcp-server
```

---

## 🎮 CÓMO USAR EL SERVIDOR MCP

### Cliente Python Básico

Crea un archivo `htb_client.py`:

```python
#!/usr/bin/env python3
import json
import subprocess
import os

class HTBMCPClient:
    def __init__(self):
        # Leer token del .env
        self.token = None
        if os.path.exists('.env'):
            with open('.env', 'r') as f:
                for line in f:
                    if line.startswith('HTB_TOKEN='):
                        self.token = line.strip().split('=', 1)[1]
                        break
        
        # Configurar entorno
        env = os.environ.copy()
        env['HTB_TOKEN'] = self.token
        env['LOG_LEVEL'] = 'INFO'
        
        # Iniciar proceso del servidor
        self.process = subprocess.Popen(
            ['./htb-mcp-server'],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=env,
            text=True,
            bufsize=1
        )
        self.request_id = 0
        
    def _send_request(self, method, params=None):
        self.request_id += 1
        request = {
            "jsonrpc": "2.0",
            "id": self.request_id,
            "method": method,
            "params": params or {}
        }
        
        request_str = json.dumps(request) + '\n'
        self.process.stdin.write(request_str)
        self.process.stdin.flush()
        
        response_line = self.process.stdout.readline()
        if not response_line:
            return {"error": "No response from server"}
        
        try:
            return json.loads(response_line)
        except json.JSONDecodeError:
            return {"error": f"Failed to parse response: {response_line}"}
    
    def initialize(self):
        """Inicializar sesión MCP"""
        return self._send_request("initialize", {
            "protocolVersion": "0.1.0",
            "capabilities": {},
            "clientInfo": {"name": "htb-client", "version": "1.0.0"}
        })
    
    def call_tool(self, tool_name, arguments):
        """Llamar una herramienta específica"""
        return self._send_request("tools/call", {
            "name": tool_name,
            "arguments": arguments
        })
    
    def close(self):
        """Cerrar el servidor"""
        if self.process:
            self.process.terminate()
            self.process.wait()
```

---

## 📋 COMANDOS DISPONIBLES

### 1. MÁQUINAS

#### Listar Máquinas
```python
client = HTBMCPClient()
client.initialize()

# Listar máquinas activas
result = client.call_tool("list_machines", {
    "status": "active",    # "active" o "retired"
    "per_page": 10         # Número de resultados
})

# Listar máquinas retiradas
result = client.call_tool("list_machines", {
    "status": "retired",
    "difficulty": "Easy",   # "Easy", "Medium", "Hard", "Insane"
    "os": "Linux"          # "Linux" o "Windows"
})
```

#### Iniciar una Máquina
```python
# Iniciar máquina por ID
result = client.call_tool("start_machine", {
    "machine_id": 701  # ID de la máquina
})

# La respuesta incluirá si fue exitoso
# Para obtener la IP, usa get_machine_ip
```

#### Obtener IP de Máquina Activa
```python
result = client.call_tool("get_machine_ip", {})
# Devuelve la IP de la máquina actualmente activa
```

#### Enviar Flags de Máquina
```python
# Flag de usuario
result = client.call_tool("submit_user_flag", {
    "machine_id": 701,
    "flag": "HTB{user_flag_here}"
})

# Flag de root
result = client.call_tool("submit_root_flag", {
    "machine_id": 701,
    "flag": "HTB{root_flag_here}"
})
```

### 2. CHALLENGES

#### Listar Challenges
```python
# Por categoría
result = client.call_tool("list_challenges", {
    "category": "Web",      # Web, Crypto, Pwn, Reversing, Forensics, etc.
    "limit": 20,
    "status": "active"      # "active" o "retired"
})

# Por dificultad
result = client.call_tool("list_challenges", {
    "difficulty": "Easy",   # Easy, Medium, Hard, Insane
    "limit": 10
})
```

#### Iniciar un Challenge
```python
# Iniciar challenge por ID
result = client.call_tool("start_challenge", {
    "challenge_id": 500  # ID del challenge
})

# Nota: Solo challenges con "container" pueden iniciarse
# Los de tipo "download" solo requieren descargar archivos
```

#### Enviar Flag de Challenge
```python
result = client.call_tool("submit_challenge_flag", {
    "challenge_id": 500,
    "flag": "HTB{challenge_flag_here}"
})
```

### 3. USUARIO

#### Obtener Perfil
```python
result = client.call_tool("get_user_profile", {})
# Devuelve información completa del usuario
```

#### Obtener Progreso
```python
result = client.call_tool("get_user_progress", {})
# Devuelve estadísticas y progreso
```

### 4. BÚSQUEDA

#### Buscar Contenido
```python
result = client.call_tool("search_content", {
    "query": "active directory",
    "type": "machine"  # "machine", "challenge", "all"
})
```

#### Estado del Servidor
```python
result = client.call_tool("get_server_status", {})
# Devuelve estado del servidor MCP y conexión HTB
```

---

## 🔧 EJEMPLOS COMPLETOS

### Ejemplo 1: Iniciar y Trabajar con una Máquina

```python
#!/usr/bin/env python3
from htb_client import HTBMCPClient

# Crear cliente
client = HTBMCPClient()
client.initialize()

# 1. Buscar máquinas Easy de Linux
print("Buscando máquinas Easy de Linux...")
result = client.call_tool("list_machines", {
    "status": "active",
    "difficulty": "Easy",
    "os": "Linux",
    "per_page": 5
})

# 2. Iniciar una máquina (ejemplo: ID 701)
print("\nIniciando máquina...")
result = client.call_tool("start_machine", {"machine_id": 701})

# 3. Obtener IP
print("\nObteniendo IP...")
result = client.call_tool("get_machine_ip", {})
# La IP estará en result['result']['content'][0]['text']

# 4. Cuando encuentres las flags
print("\nEnviando flags...")
client.call_tool("submit_user_flag", {
    "machine_id": 701,
    "flag": "HTB{user_flag}"
})

client.call_tool("submit_root_flag", {
    "machine_id": 701,
    "flag": "HTB{root_flag}"
})

client.close()
```

### Ejemplo 2: Resolver un Challenge

```python
#!/usr/bin/env python3
from htb_client import HTBMCPClient
import requests
import json

client = HTBMCPClient()
client.initialize()

# 1. Buscar challenges Web
print("Buscando challenges Web...")
result = client.call_tool("list_challenges", {
    "category": "Web",
    "limit": 10
})

# 2. Iniciar un challenge (ejemplo: ID 646)
print("\nIniciando challenge...")
result = client.call_tool("start_challenge", {"challenge_id": 646})

# 3. Obtener información de conexión
# IMPORTANTE: La IP y puerto están en el endpoint /challenge/info/{id}
token = "tu_token_htb"
response = requests.get(
    f"https://labs.hackthebox.com/api/v4/challenge/info/646",
    headers={"Authorization": f"Bearer {token}"}
)
info = response.json()['challenge']
ip = info['docker_ip']
port = info['docker_ports'][0]
print(f"Challenge en: http://{ip}:{port}")

# 4. Resolver el challenge...
# (tu código de explotación aquí)

# 5. Enviar la flag
print("\nEnviando flag...")
result = client.call_tool("submit_challenge_flag", {
    "challenge_id": 646,
    "flag": "HTB{flag_encontrada}"
})

client.close()
```

### Ejemplo 3: Script de Monitoreo

```python
#!/usr/bin/env python3
from htb_client import HTBMCPClient
import time

client = HTBMCPClient()
client.initialize()

while True:
    # Ver estado
    status = client.call_tool("get_server_status", {})
    print(f"Estado: {status}")
    
    # Ver máquina activa
    ip_result = client.call_tool("get_machine_ip", {})
    print(f"Máquina activa: {ip_result}")
    
    # Ver perfil
    profile = client.call_tool("get_user_profile", {})
    # Extraer puntos, rango, etc.
    
    time.sleep(60)  # Esperar 1 minuto

client.close()
```

---

## 🔍 OBTENER INFORMACIÓN DE CONEXIÓN

### Para Máquinas
```python
import requests

token = "tu_token"
# Máquina activa
response = requests.get(
    "https://labs.hackthebox.com/api/v4/machine/active",
    headers={"Authorization": f"Bearer {token}"}
)
data = response.json()
ip = data['info']['ip']  # IP de la máquina
```

### Para Challenges
```python
# Info completa del challenge con IP y puerto
challenge_id = 500
response = requests.get(
    f"https://labs.hackthebox.com/api/v4/challenge/info/{challenge_id}",
    headers={"Authorization": f"Bearer {token}"}
)
data = response.json()
challenge = data['challenge']
docker_ip = challenge['docker_ip']
docker_ports = challenge['docker_ports']
```

---

## 📝 TIPS Y TRUCOS

### 1. Contraseña de ZIPs
Todos los archivos ZIP de HTB usan: `hackthebox`

### 2. Límites de Cuenta Free
- Solo 1 máquina activa a la vez
- Solo 1 challenge activo a la vez
- Las máquinas tienen tiempo límite

### 3. Endpoints Especiales para Challenges

#### Blockchain Challenges
```python
# El RPC está en:
rpc_url = f"http://{ip}:{port}/rpc"

# Info de conexión:
connection_info = f"http://{ip}:{port}/connection_info"
```

#### Web Challenges
```python
# Normalmente en:
web_url = f"http://{ip}:{port}"
```

### 4. Automatización Completa

```python
#!/usr/bin/env python3
# auto_htb.py - Script automatizado

from htb_client import HTBMCPClient
import time

def auto_start_easy_machines(client):
    """Inicia automáticamente máquinas Easy"""
    
    # Buscar máquinas Easy
    result = client.call_tool("list_machines", {
        "status": "active",
        "difficulty": "Easy",
        "per_page": 10
    })
    
    # Parsear resultado y obtener IDs
    # Iniciar la primera disponible
    # etc...

def monitor_machine(client):
    """Monitorea la máquina activa"""
    while True:
        result = client.call_tool("get_machine_ip", {})
        # Procesar...
        time.sleep(30)

if __name__ == "__main__":
    client = HTBMCPClient()
    client.initialize()
    
    # Tu automatización aquí
    
    client.close()
```

---

## 🛠️ SOLUCIÓN DE PROBLEMAS

### Error: "HTB token appears invalid"
```bash
# Verificar token
curl -H "Authorization: Bearer tu_token" \
     https://labs.hackthebox.com/api/v4/user/info
```

### Error: "Machine already spawned"
```python
# Terminar máquina actual primero
# No hay endpoint en MCP para esto, usa la web de HTB
```

### Error: "No spawnable content"
- El challenge no es de tipo "container"
- Solo se puede descargar

### No puedo conectar a la IP
1. Verifica estar conectado a la VPN de HTB
2. Verifica que la instancia esté activa
3. Espera unos segundos después de iniciar

---

## 📊 ESTRUCTURA DE RESPUESTAS

### Respuesta Exitosa
```json
{
    "jsonrpc": "2.0",
    "id": 1,
    "result": {
        "content": [
            {
                "type": "text",
                "text": "Resultado de la operación"
            }
        ]
    }
}
```

### Respuesta de Error
```json
{
    "jsonrpc": "2.0",
    "id": 1,
    "error": {
        "code": -32603,
        "message": "Error message"
    }
}
```

---

## 🎯 WORKFLOW COMPLETO

1. **Configurar entorno**
   - Instalar Go
   - Compilar servidor
   - Configurar token

2. **Iniciar servidor MCP**
   ```bash
   ./htb-mcp-server
   ```

3. **Usar desde Python**
   ```python
   client = HTBMCPClient()
   client.initialize()
   # Trabajar con HTB
   client.close()
   ```

4. **Automatizar tareas**
   - Iniciar máquinas automáticamente
   - Resolver challenges
   - Enviar flags
   - Monitorear progreso

---

## 📁 ARCHIVOS INCLUIDOS

- `htb-mcp-server` - Servidor compilado
- `htb_client.py` - Cliente Python
- `examples/` - Ejemplos de uso
- `.env.example` - Plantilla de configuración
- `README_UPDATED.md` - Documentación técnica
- `PATCHES.md` - Cambios realizados
- `GUIA_COMPLETA.md` - Esta guía

---

¡Con esta guía tienes todo lo necesario para usar el servidor MCP de HTB!